function hide(button) {
    button.remove();
}
function change(element){
    document.querySelector("#b1").innerText = "Logout";
}
function incriment(element){
    document.querySelector("#num1").innerHTML++;
    alert("ninja was liked");
}
function incriment2(element){
    document.querySelector("#num2").innerHTML++;
    alert("ninja was liked");
}