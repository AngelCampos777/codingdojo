console.log("page loaded...");
function over(element) {
    element.play("mouseover");    
}
    
function out(element) {
    element.pause("mouseout");    
}

