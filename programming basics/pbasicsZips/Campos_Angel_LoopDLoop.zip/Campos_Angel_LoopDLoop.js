//release candy i=2;i=6;i+=2
//1.we are doing a repetitive task until an end condition.
//2.mile0
//3.mile6
//4.the loop will terminate after reaching the end of the tracked milage
//5.incriment of +2
//6.milage

for(m = 2; m <= 6; m += 2){
    console.log("Great Job!") //function? release candy
}

//s1 m=2;m=6;m+=2   spd mph how does the coomputer register speed? while?

var m = 2;
while(m<=6){//&& s<5.5mph
    console.log("Keep It Up");
    m+=2;
}