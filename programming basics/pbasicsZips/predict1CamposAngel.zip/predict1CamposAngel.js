//1 "i was born in 1980"
//2 "i was born in" 1980
//3summing numbers, num1 is 10, num2 is 20,30