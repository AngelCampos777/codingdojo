﻿Human johnCena = new Human("John Cena", 10, 10, 11, 100);
Human paco  = new Human("Paco");
Console.WriteLine(johnCena.Attack(paco));
